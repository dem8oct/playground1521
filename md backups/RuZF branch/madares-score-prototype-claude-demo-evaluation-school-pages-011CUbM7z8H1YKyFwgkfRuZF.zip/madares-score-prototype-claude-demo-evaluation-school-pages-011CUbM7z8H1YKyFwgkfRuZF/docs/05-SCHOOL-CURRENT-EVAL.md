# Document 05: Current Evaluation - School Admin View
## For AI Coding Agents

**Build Order:** 5th  
**Dependencies:** Documents 01-04  
**Estimated Complexity:** High

---

## Overview

This is the main interface for school administrators to complete their evaluation, upload evidence, and respond to corrections. It's the most complex view in the prototype.

**Component:** `src/pages/SchoolAdmin/CurrentEvaluation.jsx`

---

## UI Layout

```
┌──────────────────────────────────────────────────────────────┐
│ REQUEST OVERVIEW (Always Visible Header)                     │
│ Version: 2/4  |  Status: In Progress  |  Deadline: 12 days  │
│ Completion: 75% ████████████░░░░                             │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│ ⚠️ PENDING ITEMS (3 items need attention)                    │
│                                                               │
│ MISSING DATA:                                                 │
│ 1. Fire Safety Certificate upload → Go to Compliance         │
│                                                               │
│ CORRECTIONS REQUESTED:                                        │
│ 2. License expired - provide renewed license                 │
│    Ops Note: "Certificate expired June 2025, need current"   │
│    → Go to Compliance > Licensing                            │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│ DOMAIN TABS                                                   │
│ [Compliance] [Institutional Excellence] [Beneficiary Sat.]   │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│ COMPLIANCE SECTION (Current Tab - Editable)                  │
│                                                               │
│ Question 1: Do you have a valid operating license?           │
│ ○ Yes  ○ No  ○ N/A                                           │
│ Upload Evidence:                                              │
│ [Choose File] [Upload]                                        │
│ Uploaded: license_2025.pdf [View] [Remove]                   │
│                                                               │
│ ───────────────────────────────────────────                  │
│                                                               │
│ Question 2: Do you have a valid fire safety certificate?     │
│ ○ Yes  ○ No  ○ N/A                                           │
│ Upload Evidence:                                              │
│ [Choose File] ⚠️ Required                                     │
│                                                               │
│ [... more questions ...]                                      │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│ SCHOOL NOTES (Optional)                                       │
│ ┌──────────────────────────────────────────────────────┐     │
│ │ Add notes for reviewers...                           │     │
│ └──────────────────────────────────────────────────────┘     │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│ NAVIGATION                                                    │
│ [Previous]  [Save Draft]  [Submit for Review]  [Next]        │
└──────────────────────────────────────────────────────────────┘
```

---

## Implementation

```jsx
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useEvaluation } from '../../context/EvaluationContext';
import { useToast } from '../../context/ToastContext';
import { useLanguage } from '../../context/LanguageContext';
import Card from '../../components/common/Card';
import Button from '../../components/common/Button';
import Badge from '../../components/common/Badge';
import ProgressBar from '../../components/common/ProgressBar';
import Modal from '../../components/common/Modal';
import { AlertCircle, Upload, X, FileText, CheckCircle } from 'lucide-react';

const CurrentEvaluation = () => {
  const { evalId } = useParams();
  const navigate = useNavigate();
  const { getEvaluation, updateComplianceAnswer, submitEvaluation } = useEvaluation();
  const { success, error } = useToast();
  const { t } = useLanguage();

  const [evaluation, setEvaluation] = useState(null);
  const [activeTab, setActiveTab] = useState('compliance');
  const [schoolNotes, setSchoolNotes] = useState('');
  const [showSubmitModal, setShowSubmitModal] = useState(false);

  useEffect(() => {
    const eval = getEvaluation(evalId);
    if (eval) {
      setEvaluation(eval);
      setSchoolNotes(eval.school_notes || '');
    }
  }, [evalId, getEvaluation]);

  if (!evaluation) {
    return <div>Loading...</div>;
  }

  // Helper to get status color
  const getStatusColor = (status) => {
    const colors = {
      in_progress: 'warning',
      submitted: 'primary',
      returned_for_correction: 'danger',
      approved: 'success',
    };
    return colors[status] || 'default';
  };

  // Handle answer change
  const handleAnswerChange = (questionId, answer) => {
    updateComplianceAnswer(evalId, questionId, answer, []);
    success('Answer saved');
  };

  // Simulate file upload
  const handleFileUpload = (questionId, file) => {
    const question = evaluation.compliance_data.questions.find(q => q.id === questionId);
    const existingEvidence = question?.evidence || [];
    const newEvidence = [...existingEvidence, file.name];

    updateComplianceAnswer(evalId, questionId, question?.answer, newEvidence);
    success(`File "${file.name}" uploaded successfully`);
  };

  // Remove uploaded file
  const handleFileRemove = (questionId, fileName) => {
    const question = evaluation.compliance_data.questions.find(q => q.id === questionId);
    const updatedEvidence = question.evidence.filter(f => f !== fileName);

    updateComplianceAnswer(evalId, questionId, question.answer, updatedEvidence);
    success('File removed');
  };

  // Save draft
  const handleSaveDraft = () => {
    // In real app, would save schoolNotes
    success('Draft saved successfully');
  };

  // Submit for review
  const handleSubmit = () => {
    if (evaluation.completion_percentage < 100) {
      error('Please complete all required fields before submitting');
      return;
    }
    setShowSubmitModal(true);
  };

  const confirmSubmit = () => {
    submitEvaluation(evalId);
    success('Evaluation submitted for review');
    setShowSubmitModal(false);
    navigate('/school/dashboard');
  };

  // Calculate days remaining
  const getDaysRemaining = () => {
    const today = new Date();
    const deadline = new Date(evaluation.deadline);
    const days = Math.ceil((deadline - today) / (1000 * 60 * 60 * 24));
    return days;
  };

  const daysRemaining = getDaysRemaining();

  return (
    <div className="space-y-6">
      {/* Request Overview Header */}
      <Card padding="default">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Current Evaluation</h1>
            <p className="text-gray-600 mt-1">{evaluation.school_name}</p>
          </div>
          <Badge variant={getStatusColor(evaluation.status)} size="lg">
            {t(`evaluation.status.${evaluation.status}`)}
          </Badge>
        </div>

        <div className="grid grid-cols-4 gap-6">
          <div>
            <div className="text-sm text-gray-600">Version</div>
            <div className="text-lg font-semibold text-gray-900">{evaluation.version}</div>
          </div>
          <div>
            <div className="text-sm text-gray-600">Status</div>
            <div className="text-lg font-semibold text-gray-900">
              {t(`evaluation.status.${evaluation.status}`)}
            </div>
          </div>
          <div>
            <div className="text-sm text-gray-600">Deadline</div>
            <div className={`text-lg font-semibold ${daysRemaining < 3 ? 'text-danger-600' : daysRemaining < 7 ? 'text-warning-600' : 'text-success-600'}`}>
              {daysRemaining} days remaining
            </div>
            <div className="text-xs text-gray-500">{evaluation.deadline}</div>
          </div>
          <div>
            <div className="text-sm text-gray-600">Completion</div>
            <ProgressBar 
              percentage={evaluation.completion_percentage} 
              showLabel={false}
              size="md"
            />
            <div className="text-sm font-semibold text-gray-900 mt-1">
              {evaluation.completion_percentage}%
            </div>
          </div>
        </div>
      </Card>

      {/* Pending Items Alert */}
      {evaluation.pending_items && evaluation.pending_items.length > 0 && (
        <Card padding="default" className="border-l-4 border-warning-500 bg-warning-50">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-6 h-6 text-warning-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h3 className="font-semibold text-warning-900 mb-2">
                ⚠️ Pending Items ({evaluation.pending_items.length} items need attention)
              </h3>
              <ul className="space-y-2">
                {evaluation.pending_items.map((item, idx) => (
                  <li key={idx} className="text-sm text-warning-800">
                    <strong>{idx + 1}.</strong> {item.description}
                    {item.ops_comment && (
                      <div className="ml-4 mt-1 text-xs italic text-warning-700 bg-warning-100 p-2 rounded">
                        Ops Note: "{item.ops_comment}"
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </Card>
      )}

      {/* Domain Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('compliance')}
            className={`
              py-4 px-1 border-b-2 font-medium text-sm
              ${activeTab === 'compliance'
                ? 'border-primary-500 text-primary-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }
            `}
          >
            Compliance
          </button>
          <button
            onClick={() => setActiveTab('excellence')}
            className={`
              py-4 px-1 border-b-2 font-medium text-sm
              ${activeTab === 'excellence'
                ? 'border-primary-500 text-primary-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }
            `}
          >
            Institutional Excellence
          </button>
          <button
            onClick={() => setActiveTab('satisfaction')}
            className={`
              py-4 px-1 border-b-2 font-medium text-sm
              ${activeTab === 'satisfaction'
                ? 'border-primary-500 text-primary-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }
            `}
          >
            Beneficiary Satisfaction
          </button>
        </nav>
      </div>

      {/* Tab Content */}
      <div>
        {/* Compliance Tab */}
        {activeTab === 'compliance' && (
          <Card title="Compliance Questions" padding="default">
            <div className="space-y-8">
              {evaluation.compliance_data.questions.map((question, idx) => (
                <div key={question.id} className="pb-6 border-b border-gray-200 last:border-0">
                  {/* Question Header */}
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="text-base font-semibold text-gray-900 mb-1">
                        Question {idx + 1}: {question.question}
                      </h3>
                      {question.status === 'returned_for_correction' && question.ops_review && (
                        <div className="mt-2 p-3 bg-danger-50 border border-danger-200 rounded-lg">
                          <div className="flex items-start gap-2">
                            <AlertCircle className="w-4 h-4 text-danger-600 flex-shrink-0 mt-0.5" />
                            <div>
                              <div className="text-sm font-medium text-danger-900">Correction Required</div>
                              <div className="text-sm text-danger-800 mt-1">{question.ops_review.comment}</div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                    {question.status === 'complete' && (
                      <CheckCircle className="w-6 h-6 text-success-600 flex-shrink-0" />
                    )}
                  </div>

                  {/* Answer Options (for yes/no questions) */}
                  {question.type === 'yes_no' && (
                    <div className="flex gap-4 mb-4">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name={question.id}
                          value="yes"
                          checked={question.answer === 'yes'}
                          onChange={(e) => handleAnswerChange(question.id, e.target.value)}
                          className="w-4 h-4 text-primary-600 focus:ring-primary-500"
                        />
                        <span className="text-sm font-medium text-gray-700">Yes</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name={question.id}
                          value="no"
                          checked={question.answer === 'no'}
                          onChange={(e) => handleAnswerChange(question.id, e.target.value)}
                          className="w-4 h-4 text-primary-600 focus:ring-primary-500"
                        />
                        <span className="text-sm font-medium text-gray-700">No</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name={question.id}
                          value="n/a"
                          checked={question.answer === 'n/a'}
                          onChange={(e) => handleAnswerChange(question.id, e.target.value)}
                          className="w-4 h-4 text-primary-600 focus:ring-primary-500"
                        />
                        <span className="text-sm font-medium text-gray-700">N/A</span>
                      </label>
                    </div>
                  )}

                  {/* Number Input (for number questions) */}
                  {question.type === 'number' && (
                    <input
                      type="number"
                      value={question.answer || ''}
                      onChange={(e) => handleAnswerChange(question.id, e.target.value)}
                      placeholder="Enter number"
                      className="mb-4 w-full max-w-xs border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
                    />
                  )}

                  {/* Evidence Upload */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Upload Evidence {question.evidence.length === 0 && <span className="text-danger-500">*</span>}
                    </label>

                    {/* Uploaded Files */}
                    {question.evidence && question.evidence.length > 0 && (
                      <div className="space-y-2 mb-3">
                        {question.evidence.map((file, fileIdx) => (
                          <div key={fileIdx} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200">
                            <div className="flex items-center gap-2">
                              <FileText className="w-5 h-5 text-gray-400" />
                              <span className="text-sm font-medium text-gray-900">{file}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <button className="text-sm text-primary-600 hover:text-primary-700">View</button>
                              <button
                                onClick={() => handleFileRemove(question.id, file)}
                                className="text-sm text-danger-600 hover:text-danger-700"
                              >
                                Remove
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Upload Button */}
                    <div className="flex items-center gap-3">
                      <input
                        type="file"
                        id={`upload-${question.id}`}
                        onChange={(e) => {
                          if (e.target.files[0]) {
                            handleFileUpload(question.id, e.target.files[0]);
                          }
                        }}
                        className="hidden"
                      />
                      <label
                        htmlFor={`upload-${question.id}`}
                        className="cursor-pointer inline-flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                      >
                        <Upload className="w-4 h-4" />
                        Choose File
                      </label>
                      {question.evidence.length === 0 && (
                        <span className="text-sm text-gray-500">No files uploaded</span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Excellence Tab (Read-Only) */}
        {activeTab === 'excellence' && (
          <Card title="Institutional Excellence Indicators" padding="default">
            <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-blue-900">
                  <strong>Note:</strong> These indicators are calculated automatically from various data sources.
                  You cannot edit these values directly.
                </div>
              </div>
            </div>

            <div className="space-y-6">
              {evaluation.excellence_indicators.map((indicator) => (
                <div key={indicator.code} className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-gray-900">{indicator.name}</h3>
                      <p className="text-sm text-gray-600 mt-1">Weight: {indicator.weight}/5</p>
                    </div>
                    <div className="text-right">
                      <div className="text-3xl font-bold text-primary-600">{indicator.score}%</div>
                      <div className="text-xs text-gray-500 mt-1">Calculated by System</div>
                    </div>
                  </div>
                  <div className="text-sm text-gray-600">
                    Data Source: {indicator.data_source}
                  </div>
                  {indicator.details && (
                    <div className="mt-2 text-xs text-gray-500">
                      Details: {JSON.stringify(indicator.details)}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Satisfaction Tab (Read-Only) */}
        {activeTab === 'satisfaction' && (
          <Card title="Beneficiary Satisfaction Indicators" padding="default">
            <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-blue-900">
                  <strong>Note:</strong> These indicators are derived from surveys and incident reports.
                  You cannot edit these values directly.
                </div>
              </div>
            </div>

            <div className="space-y-6">
              {evaluation.satisfaction_indicators.map((indicator) => (
                <div key={indicator.code} className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-gray-900">{indicator.name}</h3>
                      <p className="text-sm text-gray-600 mt-1">Weight: {indicator.weight}/5</p>
                    </div>
                    <div className="text-right">
                      <div className="text-3xl font-bold text-primary-600">{indicator.score}%</div>
                      <div className="text-xs text-gray-500 mt-1">Calculated by System</div>
                    </div>
                  </div>
                  <div className="text-sm text-gray-600">
                    Data Source: {indicator.data_source}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>

      {/* School Notes */}
      <Card title="School Notes (Optional)" padding="default">
        <textarea
          value={schoolNotes}
          onChange={(e) => setSchoolNotes(e.target.value)}
          placeholder="Add any notes or context for reviewers..."
          rows={4}
          className="w-full border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"
        />
        <p className="text-sm text-gray-500 mt-2">
          These notes will be visible to Ministry reviewers.
        </p>
      </Card>

      {/* Navigation and Actions */}
      <div className="flex items-center justify-between">
        <Button
          variant="outline"
          onClick={() => navigate('/school/dashboard')}
        >
          Back to Dashboard
        </Button>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            onClick={handleSaveDraft}
          >
            Save Draft
          </Button>
          <Button
            variant="primary"
            onClick={handleSubmit}
            disabled={evaluation.completion_percentage < 100}
          >
            Submit for Review
          </Button>
        </div>
      </div>

      {/* Submit Confirmation Modal */}
      <Modal
        isOpen={showSubmitModal}
        onClose={() => setShowSubmitModal(false)}
        title="Submit Evaluation for Review?"
        size="md"
        footer={
          <>
            <Button variant="outline" onClick={() => setShowSubmitModal(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={confirmSubmit}>
              Confirm Submit
            </Button>
          </>
        }
      >
        <p className="text-gray-700">
          Once submitted, you cannot make changes until your submission is reviewed by Ministry staff.
          They may request corrections.
        </p>
        <div className="mt-4 p-3 bg-gray-50 rounded">
          <div className="text-sm text-gray-600">
            <strong>Completion:</strong> {evaluation.completion_percentage}%
          </div>
          <div className="text-sm text-gray-600 mt-1">
            <strong>Version:</strong> {evaluation.version}
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default CurrentEvaluation;
```

---

## Key Features

### 1. Request Overview
- Shows version, status, deadline, completion %
- Color-coded deadline warning (green/yellow/red)
- Progress bar visualization

### 2. Pending Items Alert
- Prominently displays missing data
- Shows Ops correction requests with comments
- Clear visual hierarchy (warning colors)

### 3. Compliance Section (Editable)
- Radio buttons for Yes/No questions
- Number inputs for numeric questions
- Inline file upload with preview
- Shows correction requests from Ops

### 4. Excellence/Satisfaction (Read-Only)
- Displays calculated indicators
- Shows scores and weights
- Clear "Calculated by System" labels
- Info alert explaining read-only nature

### 5. School Notes
- Optional textarea for communication
- Visible to Ops reviewers

### 6. Navigation & Actions
- Save Draft (always available)
- Submit for Review (enabled only when 100% complete)
- Confirmation modal before submission

---

## Testing Checklist

- [ ] Request overview shows correct data
- [ ] Pending items display with corrections
- [ ] Tab navigation works
- [ ] Compliance answers save correctly
- [ ] File upload simulation works
- [ ] Excellence/Satisfaction tabs show read-only data
- [ ] Save Draft shows success toast
- [ ] Submit button disabled when incomplete
- [ ] Submit modal confirms before submission
- [ ] Navigation buttons work correctly

---

## Next Steps

After completing this document:
1. ✅ Test all interactive elements
2. ✅ Verify read-only sections cannot be edited
3. ✅ Move to Document 06: Current Evaluation - Ops Reviewer View
